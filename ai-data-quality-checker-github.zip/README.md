# AI Data Quality Checker

A simple Python portfolio project inspired by real-world AI data annotation workflows.

## What it does
- Checks annotation CSV files for missing labels
- Detects invalid bounding-box coordinates
- Flags duplicate annotation IDs
- Checks confidence scores
- Produces a clean QA report

## Why I built it
As an AI/data annotator, I learned that small annotation errors can affect the quality of training data. This project demonstrates how I would automate basic quality checks before annotated data is submitted for model training.

## Run it

```bash
python qa_checker.py sample_annotations.csv
```

The script creates `qa_report.csv` containing the detected issues.

## Example
Input columns:

`annotation_id,label,x_min,y_min,x_max,y_max,confidence`

The checker validates:
- required fields
- missing labels
- bounding-box dimensions
- duplicate IDs
- confidence values from 0 to 1

## Skills demonstrated
- Python
- Data validation
- AI/ML data quality concepts
- Annotation QA
- CSV processing
- Attention to detail
- Problem solving

## Future improvements
- Add image previews
- Add a simple dashboard
- Connect to an object-detection model
- Automatically suggest corrections for common annotation errors
