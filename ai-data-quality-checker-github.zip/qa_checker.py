import csv
import sys

REQUIRED_COLUMNS = [
    "annotation_id", "label", "x_min", "y_min",
    "x_max", "y_max", "confidence"
]

def check_file(filename):
    issues = []
    seen_ids = set()

    with open(filename, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)

        missing_columns = [c for c in REQUIRED_COLUMNS if c not in reader.fieldnames]
        if missing_columns:
            raise ValueError(f"Missing columns: {', '.join(missing_columns)}")

        for row_number, row in enumerate(reader, start=2):
            annotation_id = row["annotation_id"]

            if annotation_id in seen_ids:
                issues.append([row_number, annotation_id, "Duplicate annotation ID"])
            seen_ids.add(annotation_id)

            if not row["label"].strip():
                issues.append([row_number, annotation_id, "Missing label"])

            try:
                x_min = float(row["x_min"])
                y_min = float(row["y_min"])
                x_max = float(row["x_max"])
                y_max = float(row["y_max"])
            except ValueError:
                issues.append([row_number, annotation_id, "Invalid bounding-box number"])
                continue

            if x_min < 0 or y_min < 0 or x_max < 0 or y_max < 0:
                issues.append([row_number, annotation_id, "Negative bounding-box coordinate"])

            if x_max <= x_min or y_max <= y_min:
                issues.append([row_number, annotation_id, "Invalid bounding-box dimensions"])

            try:
                confidence = float(row["confidence"])
                if not 0 <= confidence <= 1:
                    issues.append([row_number, annotation_id, "Confidence must be between 0 and 1"])
            except ValueError:
                issues.append([row_number, annotation_id, "Invalid confidence value"])

    return issues


def save_report(issues, output="qa_report.csv"):
    with open(output, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["row", "annotation_id", "issue"])
        writer.writerows(issues)


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python qa_checker.py sample_annotations.csv")
        sys.exit(1)

    issues = check_file(sys.argv[1])
    save_report(issues)

    print(f"QA complete. Found {len(issues)} issue(s).")
    print("Report saved to qa_report.csv")
